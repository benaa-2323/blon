<?php
	session_start();

?>
<!DOCTYPE html>
<html>
<head>
	<title>Đăng Nhập</title>
	<meta charset="utf-8">
	<style type="text/css">
		.content{
			text-align: center;
			border-style: outset;
			background-color:pink;
			border-radius: 10px;
			width: 400px;
			height: 260px;
			margin-top: 100px;
			margin-bottom: 100px;
			margin-right: 150px;
			margin-left: 370px;
		}
		h1{
			color: #6a5acd;
			text-shadow: 2px 2px red;
		}
	</style>
</head>
<body>

	<div class="content">
		<?php 
			$name = "";
			$password ="";

		 ?>
		<form method="POST" action="">

			<h1> Đăng nhập</h1>
			<div class="row">
				<input type="text" name="username" size="40" placeholder="Username" />
			</div><br>

			<div class="row">
				
				<input type="password" name="password" size="40" placeholder="Password" />
			</div><br>

			<div class="row">
				<td colspan="2" align="center">
				<input type="submit" name="submit" value="đăng nhập" size="10" />
				</td>
			</div><br>
			<a href="logup.php">Creat Account</a>
			<?php
			


			if (isset ($_POST['submit'])){
			$con = 	mysqli_connect("localhost","root","","demo_db");
			$sql = "SELECT * FROM user";
			$qr = mysqli_query($con,$sql);
			$name = $_POST['username'];
			$password = $_POST['password'];
			$count = "";
			 while($rs = mysqli_fetch_array($qr)){
			 	if ($rs['USr'] == $name && $rs['Pwd'] == $password) {
			 		$count = 1;
			 	}
			 	// if ($rs['USr'] == $name && $rs['Pwd'] ) {
			 	// 	$count = 2;
			 	// }
			 	// else if ($rs['USr'] != $name && $rs['Pwd'] != $password) {
			 	// 	$count =3;
			 	// }
			 	}
			 	
			 	
			 
			if ($count==1) {
				$_SESSION['user'] = $name;
				if ($rs['USr']== "admin" && $rs['Pwd'] == "12345") {
				
				header("location:./admin/index.php");
				}
				else
					{
				header("location: ./trangchu/trangchu.php");
			}
		}
			// if ($count == 2) {
			// 	echo "Sai Mật Khẩu";
			// }
			// else if ($count == 3) {
			// 	echo "Không Tìm Thấy Tài Khoản";
			// }
			
			
			else{}

			}




		?>
		</form>
	</div>

</body>
</html>