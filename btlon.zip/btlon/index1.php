<!DOCTYPE html>
<html>
<head>
	<title>Trang Sản Phẩm</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="css.css">
</head>
<body>
	<?php

		include'./connect.php';
		//include'./pagination.php';
		$item_per_page = !empty($_GET['per_page']) ? $_GET['per_page']:4;

		$current_page = !empty($_GET['page']) ? $_GET['page']:1;
		$offset = ($current_page - 1) * $item_per_page ;
		$products = mysqli_query($con,"SELECT * FROM product ORDER BY id ASC LIMIT ".$item_per_page." OFFSET ".$offset);
		$totalRecords = mysqli_query($con,"SELECT* FROM product");
		$totalRecords = $totalRecords->num_rows;
		$totalPages = ceil($totalRecords /$item_per_page);

	?>
	<div class="container">
		<h1>Danh sách sản phẩm</h1>
		<?php
			while ($row = mysqli_fetch_array($products))
				{


		?>
		<div class="product-items">
			
			<div class="product-img">
				<img src="IMG/p-1.jpg" title="Phone 1" alt="Not Found">
				
			</div>
			<strong><?php echo $row['name']; ?>
				
			</strong>
			<label>Giá: </label>
			<span class="product-price"><?php
			echo (number_format($row['price'])); ?>
				
			</span>
			<br>
			<div class="buy-button">
			<a href="#">Buy</a>	
			</div>
		</div>
		<?php
			}
		?>
	</div>	
	<div style="margin-top: 20px;float: left;">
		<?php
	include './pagination.php';
	?>
	</div>
</body>
</html>