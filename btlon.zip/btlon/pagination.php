<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>&nbsp;
	<div>
		<a href="?per_page=4&page=1">1</a>
		<a href="?per_page=4&page=2">2</a>
		<a href="?per_page=4&page=3">3</a>
	</div>
		
</body>
</html>