<?php
	$con = mysqli_connect("localhost","root","","demo_db");
	mysqli_set_charset($con,"UTF8");

	if(mysqli_connect_error())
		{
			echo "Lỗi kết nối";
			mysqli_connect_error();
			exit();
		}
	else{
		//echo " kết nối thành coong"
	}



?>