<!DOCTYPE html>
<html>
<head>
	<title>bai1</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="font-fa-master/css/font-awesome.css">
</head>
<body>
	<div>
		<div id="top">
			<div class="container">
				<div class="row">
					<div class="col-4">
						<h5 align="center"><i class="fa fa-clock-o fa-2x"></i>30 DAYS RETURN</h5><p align="center">moneyback guarantee</p>
					</div>
					<div class="col-4">
						<h5 align="center"><i class="fa fa-truck fa-2x"></i>FREE SHIPPING ON $30</h5><p align="center">On all over order $99</p>
					</div>
					<div class="col-4">
						<h5 align="center"><i class="fa fa-tag fa-2x"></i> SAFE SHOPPING</h5><p align="center">Save up 50% to now</p>
					</div>
				</div>
			</div>
		</div>
		<div class="container shadow p-3 mb-5 bg-white" id="menu">
			<div class="row">
				<div class="col">
					<nav class="nav">
						<li class="nav-item dropdown">
			        		<a class="nav-link dropdown-toggle text-muted" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">English
			        		</a>
			        		<div class="dropdown-menu" aria-labelledby="navbarDropdown">
			          			<a class="dropdown-item text-muted" href="#">Action</a>
			          			<a class="dropdown-item text-muted" href="#">Another action</a>
			          			<div class="dropdown-divider"></div>
			          			<a class="dropdown-item text-muted" href="#">Something else here</a>
			     			</div>
			    		</li>
			    		<li class="nav-item dropdown">
				        	<a class="nav-link dropdown-toggle text-muted" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">USD
				        	</a>
				        	<div class="dropdown-menu" aria-labelledby="navbarDropdown">
				          		<a class="dropdown-item text-muted" href="#">Action</a>
				          		<a class="dropdown-item text-muted" href="#">Another action</a>
				          		<div class="dropdown-divider"></div>
				          		<a class="dropdown-item text-muted" href="#">Something else here</a>
				     		</div>
			    		</li>
		    		</nav>
				</div>
				<div class="col">
					<ul class="nav justify-content-end row">
						<li class="col">
	    					<a class="text-muted" href="#"><i class="fa fa-heart"></i>Whislist</a>
	 					</li>
	 					<li class="col">
	    					<a class="text-muted" href="#"><i class="fa fa-user"></i>MyAccount</a>
	 					</li>
	 					<li class="col">
	    					<a class="text-muted" href="#"><i class="fa fa-check-square-o"></i>Check out</a>
	 					</li>
	 					<li class="col">
	    					<a class="text-muted" href="#"><i class="fa fa-lock"></i>Login</a>
	 					</li>
					</ul>
				</div>
			</div>
			<div class="row">
				<div class="col-4"></div>
				<div align="center" class="col-4">
					<h1 align="center">MARKET</h1><p align="center">Shop all you want</p>
				</div>
				<div class="col-4">
					<form class="form-inline my-2 my-lg-0">
				      <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
				      <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
				    </form>
				</div>
			</div>
			<div class="row">
				<div class="col">
					<nav class="nav">
						<li class="nav-item dropdown">
			        		<a class="nav-link dropdown-toggle text-muted" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">HOME
			        		</a>
			        		<div class="dropdown-menu" aria-labelledby="navbarDropdown">
			          			<a class="dropdown-item text-muted" href="#">Action</a>
			          			<a class="dropdown-item text-muted" href="#">Another action</a>
			          			<div class="dropdown-divider"></div>
			          			<a class="dropdown-item text-muted" href="#">Something else here</a>
			     			</div>
			    		</li>
			    		<li class="nav-item dropdown">
				        	<a class="nav-link dropdown-toggle text-muted" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">NEW ARRIVALS
				        	</a>
				        	<div class="dropdown-menu" aria-labelledby="navbarDropdown">
				          		<a class="dropdown-item text-muted" href="#">Action</a>
				          		<a class="dropdown-item text-muted" href="#">Another action</a>
				          		<div class="dropdown-divider"></div>
				          		<a class="dropdown-item text-muted" href="#">Something else here</a>
				     		</div>
			    		</li>
			    		<li class="nav-item active">
					        <a class="nav-link text-dark" href="#">PROMOTION</a>
					    </li>
					    <li class="nav-item dropdown">
				        	<a class="nav-link dropdown-toggle text-muted" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">SPECIAL
				        	</a>
				        	<div class="dropdown-menu" aria-labelledby="navbarDropdown">
				          		<a class="dropdown-item text-muted" href="#">Action</a>
				          		<a class="dropdown-item text-muted" href="#">Another action</a>
				          		<div class="dropdown-divider"></div>
				          		<a class="dropdown-item text-muted" href="#">Something else here</a>
				     		</div>
			    		</li>
			    		<li class="nav-item active">
					        <a class="nav-link text-dark" href="#">BLOG</a>
					    </li>
					    <li class="nav-item active">
					        <a class="nav-link text-dark" href="#">CONTACT US</a>
					    </li>
					    <li class="nav-item active">
					        <a class="nav-link text-dark" href="#">ABOUT US</a>
					    </li>
		    		</nav>
				</div>
			</div>
			<div class="container">
				<div class="row">
					<div class="col-9">
						<img src="images/1.jpg" width="800px">
					</div>
					<div class="col-3">
						<img src="images/2.jpg" width="260px">
						<img src="images/3.jpg" width="260px" style="margin-top: 10px">
					</div>
				</div>
			</div>
			<div class="container">
				<img src="images/4.jpg" width="1100px">
			</div>
			<div class="container">
				<div class="row">
					<div class="col-4">
						<img src="images/5.jpg" width="352px">
					</div>
					<div class="col-4">
						<img src="images/6.jpg" width="352px">
					</div>
					<div class="col-4">
						<img src="images/7.jpg" width="352px">
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-6">
					<b>
						NEW ARRIVALS
					</b>	
				</div>
				<div class="col-6">
					<div class="row">
						<div class="col-9"></div>
						<div class="col-1">
							<button><img src="images/prev.jpg"></button>
						</div>
						<div class="col-1">
							<button><img src="images/next.jpg"></button>
						</div>
						<div class="col-1"></div>
					</div>
				</div>
			</div>

			<hr style="background-color: #dbdbdb;">
			
			<div class="row">
				<div class="col-3" id="sp">
					<img src="images/mh1.jpg">
					<div class="row">
						<div class="col-2"></div>
						<div class="col-9">
							Duis autem veleum
						</div>
					</div>
					<div class="row">
						<div class="col-3"></div>
						<div class="col-6">
							<i class="fa fa-star" style="color:#f4a338;"></i>
							<i class="fa fa-star" style="color:#f4a338;"></i>
							<i class="fa fa-star" style="color:#f4a338;"></i>
							<i class="fa fa-star" style="color:#f4a338;"></i>
							<i class="fa fa-star-o"></i>
						</div>
						<div class="col-3"></div>
					</div>
					<div class="row">
						<div class="col-2"></div>
						<div class="col-3" style="color: red;">$116.00</div>
						<div class="col-3"><del>$127.00</del></div>
						<div class="col-3"></div>
					</div>
					<div class="row">
						<div class="col-3"></div>
						<div class="col-1">
							<button><i class="fa fa-shopping-cart" id="khung"></i></button>
						</div>
						<div class="col-1">
							<button><i class="fa fa-heart" id="khung"></i></button>
						</div>
						<div class="col-1">
							<button><i class="fa fa-list-alt" id="khung"></i></button>
						</div>
					</div>
				</div>

				<div class="col-3" id="sp">
					<img  src="images/mh2.jpg">
					<div class="row">
						<div class="col-2"></div>
						<div class="col-9">
							Duis autem veleum
						</div>
					</div>
					<div class="row">
						<div class="col-3"></div>
						<div class="col-6">
							<i class="fa fa-star" style="color:#f4a338;"></i>
							<i class="fa fa-star" style="color:#f4a338;"></i>
							<i class="fa fa-star" style="color:#f4a338;"></i>
							<i class="fa fa-star" style="color:#f4a338;"></i>
							<i class="fa fa-star-o"></i>
						</div>
						<div class="col-3"></div>
					</div>
					<div class="row">
						<div class="col-2"></div>
						<div class="col-3" style="color: red;">$116.00</div>
						<div class="col-3"><del>$127.00</del></div>
						<div class="col-3"></div>
					</div>
					<div class="row">
						<div class="col-3"></div>
						<div class="col-1">
							<button><i class="fa  fa-shopping-cart" id="khung"></i></button>
						</div>
						<div class="col-1">
							<button><i class="fa  fa-heart" id="khung"></i></button>
						</div>
						<div class="col-1">
							<button><i class="fa  fa-list-alt" id="khung"></i></button>
						</div>
					</div>
				</div>

				<div class="col-3" id="sp">
					<img src="images/mh3.jpg">
					<div class="row">
						<div class="col-2"></div>
						<div class="col-9">
							Duis autem veleum
						</div>
					</div>
					<div class="row">
						<div class="col-3"></div>
						<div class="col-6">
							<i class="fa fa-star" style="color:#f4a338;"></i>
							<i class="fa fa-star" style="color:#f4a338;"></i>
							<i class="fa fa-star" style="color:#f4a338;"></i>
							<i class="fa fa-star" style="color:#f4a338;"></i>
							<i class="fa fa-star-o"></i>
						</div>
						<div class="col-3"></div>
					</div>
					<div class="row">
						<div class="col-2"></div>
						<div class="col-3" style="color: red;">$116.00</div>
						<div class="col-3"><del>$127.00</del></div>
						<div class="col-3"></div>
					</div>
					<div class="row">
						<div class="col-3"></div>
						<div class="col-1">
							<button><i class="fa  fa-shopping-cart" id="khung"></i></button>
						</div>
						<div class="col-1">
							<button><i class="fa  fa-heart" id="khung"></i></button>
						</div>
						<div class="col-1">
							<button><i class="fa  fa-list-alt" id="khung"></i></button>
						</div>
					</div>
				</div>

				<div class="col-3" id="sp">
					<img src="images/mh4.jpg">
					<div class="row">
						<div class="col-2"></div>
						<div class="col-10">
							Duis autem veleum
						</div>
					</div>
					<div class="row">
						<div class="col-3"></div>
						<div class="col-6">
							<i class="fa fa-star" style="color:#f4a338;"></i>
							<i class="fa fa-star" style="color:#f4a338;"></i>
							<i class="fa fa-star" style="color:#f4a338;"></i>
							<i class="fa fa-star" style="color:#f4a338;"></i>
							<i class="fa fa-star-o"></i>
						</div>
						<div class="col-3"></div>
					</div>
					<div class="row">
						<div class="col-2"></div>
						<div class="col-3" style="color: red;">$116.00</div>
						<div class="col-3"><del>$127.00</del></div>
						<div class="col-3"></div>
					</div>
					<div class="row">
						<div class="col-3"></div>
						<div class="col-1">
							<button><i class="fa  fa-shopping-cart" id="khung"></i></button>
						</div>
						<div class="col-1">
							<button><i class="fa  fa-heart" id="khung"></i></button>
						</div>
						<div class="col-1">
							<button><i class="fa  fa-list-alt" id="khung"></i></button>
						</div>
					</div>
				</div>
			</div>

			<div class="row">
				<div class="col-3">
					<img src="images/8.jpg">
				</div>
				<div class="col-6">
					<img src="images/9.jpg" width="560px;" height="540px;">
				</div>
				<div class="col-3">
					<div class="row">
						<img src="images/11.jpg" width="270px;" height="270px;" >
					</div>
					<div class="row">
						<img src="images/10.jpg" width="270px;" height="270px;">
					</div>
				</div>
			</div>

			<div class="row">
				<div class="col-6">
				 <ul class="nav justify-content-center">
			 	  <li class="nav-item" id="doc2">
			  	     <a class="nav-link active" href="#" style="color: black;">
			    		<b>
			    			FEATURED
			    		</b>
					 </a>
			 	  </li>
			  	  <li class="nav-item" id="doc2">
			        <a class="nav-link" href="#" style="color: #8c8c8c;">
			   			<b>
			   				NEW ARRIVALS
			   			</b> 
					</a>
			 	  </li>
			 	  <li class="nav-item">
			   		 <a class="nav-link" href="#" style="color: #8c8c8c;">
			    		<b>
			    			BEST SELLERS
			    		</b>
			    	</a>
			  	  </li>
				</ul>
				</div>
				<div class="col-6">
					<div class="row">
						<div class="col-9"></div>
						<div class="col-1">
							<button><img src="images/prev.jpg"></button>
						</div>
						<div class="col-1">
							<button><img src="images/next.jpg"></button>
						</div>
						<div class="col-1"></div>
					</div>
				</div>
			</div>
			<hr style="background-color: #dbdbdb;">

			<div class="row" align="center">
				<div class="col-2" id="ff">
					<img src="images/mh5.jpg">
					<div class="row">
						<div class="col-1"></div>
						<div class="col-11" align="center">
							Duis autem veleum
						</div>
					</div>
					<div class="row">
						<div class="col-11">
							<i class="fa fa-star" style="color:#f4a338;"></i>
							<i class="fa fa-star" style="color:#f4a338;"></i>
							<i class="fa fa-star" style="color:#f4a338;"></i>
							<i class="fa fa-star" style="color:#f4a338;"></i>
							<i class="fa fa-star-o"></i>
						</div>
					</div>
					<div class="row">
						<div class="col-3" style="color: red;">$116.00</div>
						<div class="col-1"></div>
						<div class="col-3"><del>$127.00</del></div>
						<div class="col-3"></div>
					</div>

					<div class="row">
						<div class="col-1"></div>
						<div class="col-1">
							<button><i class="fa  fa-shopping-cart" id="khung"></i></button>
						</div>
						<div class="col-1">
							<button><i class="fa  fa-heart" id="khung"></i></button>
						</div>
						<div class="col-1">
							<button><i class="fa  fa-list-alt" id="khung"></i></button>
						</div> 
						<div class="col-1"></div>
					</div>
				</div>	

				<div class="col-2" id="ff">
					<img src="images/mh6.jpg">
					<div class="row">
						<div class="col-1"></div>
						<div class="col-11">
							Duis autem veleum
						</div>
					</div>
					<div class="row">
						<div class="col-11">
							<i class="fa fa-star" style="color:#f4a338;"></i>
							<i class="fa fa-star" style="color:#f4a338;"></i>
							<i class="fa fa-star" style="color:#f4a338;"></i>
							<i class="fa fa-star" style="color:#f4a338;"></i>
							<i class="fa fa-star-o"></i>
						</div>
					</div>
					<div class="row">
						<div class="col-3" style="color: red;">$116.00</div>
						<div class="col-1"></div>
						<div class="col-3"><del>$127.00</del></div>
						<div class="col-3"></div>
					</div>

					<div class="row">
						<div class="col-1"></div>
						<div class="col-1">
							<button><i class="fa  fa-shopping-cart" id="khung"></i></button>
						</div>
						<div class="col-1">
							<button><i class="fa  fa-heart" id="khung"></i></button>
						</div>
						<div class="col-1">
							<button><i class="fa  fa-list-alt" id="khung"></i></button>
						</div> 
						<div class="col-1"></div>
					</div>
				</div>

				<div class="col-3" id="ff">
					<img src="images/mh7.jpg">
					<div class="row">
						<div class="col-1"></div>
						<div class="col-11">
							Duis autem veleum
						</div>
					</div>
					<div class="row">
						<div class="col-11">
							<i class="fa fa-star" style="color:#f4a338;"></i>
							<i class="fa fa-star" style="color:#f4a338;"></i>
							<i class="fa fa-star" style="color:#f4a338;"></i>
							<i class="fa fa-star" style="color:#f4a338;"></i>
							<i class="fa fa-star-o"></i>
						</div>
					</div>
					<div class="row">
						<div class="col-2"></div>
						<div class="col-3" style="color: red;">$116.00</div>
						<div class="col-1"></div>
						<div class="col-3"><del>$127.00</del></div>
						<div class="col-3"></div>
					</div>

					<div class="row">
						<div class="col-3"></div>
						<div class="col-1">
							<button><i class="fa  fa-shopping-cart" id="khung"></i></button>
						</div>
						<div class="col-1">
							<button><i class="fa  fa-heart" id="khung"></i></button>
						</div>
						<div class="col-1">
							<button><i class="fa  fa-list-alt" id="khung"></i></button>
						</div> 
						<div class="col-1"></div>
					</div>	

				</div>

				<div class="col-2" id="ff">
					<img src="images/mh8.jpg">
							<div class="row">
						<div class="col-1"></div>
						<div class="col-11">
							Duis autem veleum
						</div>
					</div>
					<div class="row">
						<div class="col-11">
							<i class="fa fa-star" style="color:#f4a338;"></i>
							<i class="fa fa-star" style="color:#f4a338;"></i>
							<i class="fa fa-star" style="color:#f4a338;"></i>
							<i class="fa fa-star" style="color:#f4a338;"></i>
							<i class="fa fa-star-o"></i>
						</div>
					</div>
					<div class="row">
						<div class="col-3" style="color: red;">$116.00</div>
						<div class="col-1"></div>
						<div class="col-3"><del>$127.00</del></div>
						<div class="col-3"></div>
					</div>

					<div class="row">
						<div class="col-1"></div>
						<div class="col-1">
							<button><i class="fa  fa-shopping-cart" id="khung"></i></button>
						</div>
						<div class="col-1">
							<button><i class="fa  fa-heart" id="khung"></i></button>
						</div>
						<div class="col-1">
							<button><i class="fa  fa-list-alt" id="khung"></i></button>
						</div> 
						<div class="col-1"></div>
					</div>
				</div>


				<div class="col-2" id="ff">
					<img src="images/mh9.jpg">
							<div class="row">
						<div class="col-1"></div>
						<div class="col-11">
							Duis autem veleum
						</div>
					</div>
					<div class="row">
						<div class="col-11">
							<i class="fa fa-star" style="color:#f4a338;"></i>
							<i class="fa fa-star" style="color:#f4a338;"></i>
							<i class="fa fa-star" style="color:#f4a338;"></i>
							<i class="fa fa-star" style="color:#f4a338;"></i>
							<i class="fa fa-star-o"></i>
						</div>
					</div>
					<div class="row">
						<div class="col-3" style="color: red;">$116.00</div>
						<div class="col-1"></div>
						<div class="col-3"><del>$127.00</del></div>
						<div class="col-3"></div>
					</div>

						<div class="row">
						<div class="col-1"></div>
						<div class="col-1">
							<button><i class="fa  fa-shopping-cart" id="khung"></i></button>
						</div>
						<div class="col-1">
							<button><i class="fa  fa-heart" id="khung"></i></button>
						</div>
						<div class="col-1">
							<button><i class="fa  fa-list-alt" id="khung"></i></button>
						</div> 
						<div class="col-1"></div>
					</div>
				</div>
				
			</div>

			<div class="container" style="background-color: #f2f2f2;">
				<div class="row">
					<div class="col-6">

					<div class="col-2"></div>
					<div class="col-8">
						<div class="row">
							<div class="col-3"></div>
							<div class="col-6">
								<h5>THIS WEEK</h5>
							</div>
							<div class="col-3"></div>
						</div>	

						<div class="row">
							<div class="col-12" style="opacity: 0.6;">
								Introducing James Jagger for AW16 Men's
							</div>
						</div>
						<div class="row">
							<div class="col-4"></div>
							<div class="col-4">
								View more
							</div>
							<div class="col-4"></div>
						</div>

						<div class="row">
							<div class="col-3"></div>
							<div class="col-7" style="opacity: 0.6;">
								Autumn Winter 2016
							</div>
							<div class="col-2"></div>
						</div>
						<div class="row">
							<div class="col-4"></div>
							<div class="col-4">
								View more
							</div>
							<div class="col-4"></div>
						</div>

						<div class="row">
							<div class="col-12" style="opacity: 0.6;">
								Introducing James Jagger for AW16 Men's
							</div>
						</div>
						<div class="row">
							<div class="col-4"></div>
							<div class="col-4">
								View more
							</div>
							<div class="col-4"></div>
						</div>
					</div>
					<div class="col-2"></div>
				</div>






				<div class="col-6">

							<div class="row">
								<div class="col-4"></div>
								<div class="col-4">
									<div class="row">
										<div class="col-12">
											<h5>KEEP IN TOUCH...</h5>
										</div>
									</div>
									
								</div>
								<div class="col-4"></div>
							</div>	

							<div class="row">
								<div class="col-2"></div>
								<div class="col-10">
									<p align="center">
										Get style updates straight to your inbox. Simply enter your details below to keep up-to-date with the laterst news on collec-tions and exclusive events
									</p>
								</div>
								<div class="col-2"></div>
							</div>	

								<div class="row">
									<div class="col-2"></div>
									<div class="col-8">
									<div class="input-group">
								    <input type="text" class="form-control" id="search" placeholder="Search" aria-label="Input group example" aria-describedby="btnGroupAddon">
								    <div class="input-group-prepend">
								      <div class="btn btn-warning" id="btnGroupAddon"><i class="fa  fa-search"></i></div>
								      </div>
								    </div>
								 </div>
								 <div class="col-2"></div>
							 
								</div>

						</div>
					</div>
				</div>


				<div class="container">

					<div class="row">
					<div class="col-2"></div>
					<div class="col-2">
						<h4>FOLLOW US</h4>
					</div>
					<div class="col-6">
						<i class="fa  fa-facebook-official" style="font-size: 35px;" id="icon"></i>
						<i class="fa  fa-twitter-square" style="font-size: 35px;" id="icon"></i>
						<i class="fa  fa-google-plus-square" style="font-size: 35px;" id="icon"></i>
						<i class="fa  fa-xing-square" style="font-size: 35px;" id="icon"></i>
						<i class="fa  fa-camera" style="font-size: 35px;" id="icon"></i>
						<i class="fa  fa-youtube-play" style="font-size: 35px;" id="icon"></i>
					</div>
					<div class="col-2"></div>
				</div>
			</div>

			<div class="container">
				<div class="row">
					<div class="col-3">
						<div class="row">
							<div class="col-2"></div>
							<div class="col-10">
								<div class="row">
									<h5>OUR SHOP</h5>
								</div>

								<div class="row" style="opacity: 0.6;">
									Product Support
								</div>

								<div class="row" style="opacity: 0.6;">
									PC Setup & Support
								</div>

								<div class="row" style="opacity: 0.6;">
									Services
								</div>

								<div class="row" style="opacity: 0.6;">
									Extended Service Plans
								</div>

								<div class="row" style="opacity: 0.6;">
									Community
								</div>
							</div>
						</div>
					</div>
					<div class="col-2">
						<div class="row">
							<div class="col-2"></div>
							<div class="col-10">
								<div class="row">
									<h5> ORDERS</h5>
								</div>

								<div class="row" style="opacity: 0.6;">
									My Account 
								</div>

								<div class="row" style="opacity: 0.6;">
									Order Tracking
								</div>

								<div class="row" style="opacity: 0.6;">
									Watch Lish
								</div>

								<div class="row" style="opacity: 0.6;">
									Customer Service
								</div>

								<div class="row" style="opacity: 0.6;">
									Returns / Exchanges
								</div>
							</div>
						</div>
					</div>
					<div class="col-3">
						<div class="row">
							<div class="col-2"></div>
							<div class="col-10">
								<div class="row">
									<h5>OUR SHOP</h5>
								</div>

								<div class="row" style="opacity: 0.6;">
									Product Support
								</div>

								<div class="row" style="opacity: 0.6;">
									PC Setup & Support
								</div>

								<div class="row" style="opacity: 0.6;">
									Services
								</div>

								<div class="row" style="opacity: 0.6;">
									Extended Service Plans
								</div>

								<div class="row" style="opacity: 0.6;">
									Community
								</div>
							</div>
						</div>
					</div>
					<div class="col-4">
						<div class="row">
							<div class="col-12">
								<div class="row">
									<h5>CONTACT US</h5>
								</div>
								<div class="row">
									<div class="col-2">
										 <i class="fa  fa-get-pocket" style="font-size: 30px;"></i>
									</div>
									<div class="col-10" style="opacity: 0.6;">
										Address: No 40 Baria Street 133/2 NewYork City, NY United States
									</div>
								</div>

								<div class="row">
									<div class="col-2">
										<i class="fa  fa-envelope-square" style="font-size: 30px;"></i>
									</div>
									<div class="col-10" style="opacity: 0.6;">
										Email: contact@market.com
									</div>
								</div>

								<div class="row">
									<div class="col-2">
										<i class="fa fa-phone-square" style="font-size: 30px;"></i>
									</div>
									<div class="col-10" style="margin-top: -20px;">
										<p style="opacity: 0.6;">Phone 1: 0123456789</p>
										<p style="margin-top: -15px; opacity: 0.6;">Phone 2: 0123456789</p>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>

			<div class="container" style="background-color: #f2f2f2;">
				<div class="row">
					<div class="col-6" style="font-size: 15px;">
					&copy;2016 Magento Themes Demo Store. All Rights Reserved. Designed by <i style="color: green;">Phương Lan</i>
					</div>
					<div class="col-6">
						<div class="row">
							<div class="col-5"></div>
							<div class="col-7">
								<div class="row">
									<i class="fa  fa-cc-visa" style="font-size: 30px; opacity: 0.6;"></i>

									<i class="fa  fa-cc-paypal" style="font-size: 30px; opacity: 0.6;"></i>

									<i class="fa  fa-cc-diners-club" style="font-size: 30px; opacity: 0.6;"></i>

									<i class="fa  fa-cc-discover" style="font-size: 30px; opacity: 0.6;"></i>

									<i class="fa  fa-cc-mastercard" style="font-size: 30px; opacity: 0.6;"></i>

									<i class="fa  fa-cc-amex" style="font-size: 30px; opacity: 0.6;"></i>
								</div>
							</div>
						</div>		
					</div>
				</div>
			</div>
		</div>
	</div>
	<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
	<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
</body>
</html>