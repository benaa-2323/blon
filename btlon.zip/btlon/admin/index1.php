<!DOCTYPE html>
<html>
<head>
	<title>ADMIN</title>
	<meta charset="utf-8">
	<style type="text/css">
		h1{
			text-align: center;
			color: red;
		}
	</style>
</head>
<body>
	<form>
		<h1>Danh Sách ADMIN</h1>
		<table align="center" border="2" cellpadding="10" cellspacing="0">
			<tr>
				<td>
					USr
				</td>

				<td>
					fullname
				</td>

				<td>
					Pwd
				</td>

				<td>
					Delete Account
				</td>

				<td>
					Change Account
				</td>
			</tr>
			<?php
				$con = mysqli_connect("localhost","root","","demo_db");
				$sql = "SELECT * FROM user";
				$qr = mysqli_query($con,$sql);
				
				while ($ad =mysqli_fetch_array($qr)) {
					echo "<tr>";
						echo "<td>".$ad['USr']."</td>";
						echo "<td>".$ad['fullname']."</td>";
						echo "<td>".$ad['Pwd']."</td>";
						echo "<td>"."<a href =' xoataikhoan.php?id=".$ad['id']."'>Xoá Thông Tin </a></td>";
						echo "<td>"."<a href ='suataikhoan.php?id=".$ad['id']."'>Sửa Thông Tin  </a></td>";
					echo "</tr>";
				}

			?>
		</table>

		<div align="center">
		 <a href ='themtaikhoan.php' >thêm tài khoản </a>;
		</div>
	</form>
	<a href="../login.php">LOGIN</a>
</body>
</html>