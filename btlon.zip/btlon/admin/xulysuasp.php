<?php
session_start();
	$id = $_POST['id'];

	$TenSp = $_POST['tsp'];
	$GiaTien = $_POST['gt'];

	$con = mysqli_connect("localhost","root","","demo_db");

	function randomString($lenght =5){
		$arrCharacter = array_merge(range('A', 'Z'),range('a', 'z'),range(0, 9));
		$arrCharacter = implode($arrCharacter, '');
		$arrCharacter = str_shuffle($arrCharacter);
		$result = substr($arrCharacter,0,$lenght);
		return $result;
	}

	$FILE = $_FILES['img'];
	$x ="";
	if ($FILE['name'] != null) {
		$filename = $FILE['tmp_name'];
		$random = randomString(6);
		$destination = '../IMG/'.$random .$FILE['name'];
		$x = $FILE['name'];
		if (move_uploaded_file($filename, $destination)) {

			$x = $FILE['name'];
			$sql2 = "UPDATE product SET TenSp= '$TenSp',image = '$x',GiaTien ='$GiaTien' where id = $id";
			$qr2 = mysqli_query($con,$sql2);
			header("location: showsp.php");
		}

	}
	echo "<pre>";
	print_r($_FILES);
	echo "</pre>";
?>
