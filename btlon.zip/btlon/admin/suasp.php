<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<title>CHANGE PRODUCT</title>
	<style type="text/css">
		#left{
			width: 50%;

		}
		#right{
			width: 50%;
		}
		img{
			float: left;
			width: 700px;
			height: 200px;
		}
		input[type='submit']{
			width: 200px;
			margin-left: 640px;
		}
	</style>  
</head>
<body>
	<h1 align="center"> 
		CHANGE PRODUCTS
	</h1>
	<form method="POST" action="xulysuasp.php" enctype="multipart/form-data">
		<?php
			$id = $_GET['id'];
			$con = mysqli_connect("localhost","root","","demo_db");
			$sql= "SELECT * FROM product where id='$id'";
			$qr = mysqli_query($con,$sql);
			$rs = mysqli_fetch_array($qr);
		?>
		<div class="main">
			<table width="100%" border="1" cellspacing="0" cellpadding="50">
				<input type="hidden" name="id" value="<?php echo $id ?>">
				<tr>
					<td id="left">
						<?php echo '<img src="../IMG/'.$rs["image"].'">'?>
					</td>
					<td id="right">
						<input type="file" name="img">
					</td>
				</tr>

				<tr>
					<td id="left">
						Tên Sản Phẩm
					</td>
					<td id="right"> 
						<input type="text" name="tsp" value="<?php echo $rs['name'] ?>">
					</td>
				</tr>

				<tr>
					<td id="left">
						Giá tiền:
					</td>
					<td id="right">
						<input type="text" name="gt" value="<?php echo $rs['price']?>">
					</td>
				</tr>

				<tr>
					<td colspan="2">
						<input type="submit" name="submit" value="CHANGE">
					</td>
				</tr>
			</table>
		</div>
	</form>
</body>
</html>