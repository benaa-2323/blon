<!DOCTYPE html>
<html>
<head>
	<title>add</title>
	<meta charset="utf-8">

</head>
<body>
	<form method="POST" action="xulythemtaikhoan.php">
		<h1 align="center">Thêm Người Dùng</h1>
		<table align="center" border="2" cellpadding="10" cellspacing="0">
			<tr>
				<td>
					USr
				</td>
				<td>
					fullname
				</td>
				<td>
					Pwd
				</td>
			</tr>

			<tr>
				<td>
					<input type="text" name="USr">
				</td>
				<td>
					<input type="text" name="fullname">
				</td>
				<td>
					<input type="text" name="Pwd">
				</td>
			</tr>
			<tr>
				<td colspan="3">
				<input type="submit" value="SEND" name="">
				</td>
			</tr>

			
		</table>
		<div align="center">
			<a href="index.php">Quay Lại</a>
		</div>

		
	</form>
</body>
</html>