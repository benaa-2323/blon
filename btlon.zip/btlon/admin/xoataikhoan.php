<?php
	$id = $_GET['id'];
	$con = 	mysqli_connect("localhost","root","","demo_db");
	$sql = "DELETE FROM user WHERE id='$id'";
	$qr = mysqli_query($con,$sql);
	if ($qr ) {
		header('location:index.php');
	}


?>