<?php
	$id = $_POST['id'];

	$USr = $_POST['USr'];
	$fullname = $_POST['fullname'];
	$Pwd = $_POST['Pwd'];

	$con = mysqli_connect("localhost","root","","demo_db");
	$sql ="UPDATE user SET USr ='$USr',fullname='$fullname',Pwd= '$Pwd' WHERE id='$id'";
	$qr = mysqli_query($con,$sql);

	if ($qr) {
		header("location: index.php");
	}


?>