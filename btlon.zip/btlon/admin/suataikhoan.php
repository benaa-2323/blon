<!DOCTYPE html>
<html>
<head>
	<title></title>
	<meta charset="utf-8">
	<style type="text/css">
		h1{
			color: red;
		}
		input[type='submit']{
			width: 200px;
		}
	</style>
</head>
<?php $id = "" ;?>
<body>
	<form method="POST" action="xulysuataikhoan.php">
		<?php

			$id = $_GET['id'] ;

			$con = mysqli_connect("localhost","root","","demo_db");
			$sql  = "SELECT * FROM user WHERE id ='$id'";

			$qr = mysqli_query($con,$sql);

			$ad = mysqli_fetch_array($qr);

		?>
		<h1 align="center" >  
			Sửa Thông Tin ADMIN
		</h1>
		<table align="center" border="2px" cellspacing="0" cellpadding="10">
			<tr>
				<td>
					USr
				</td>
				<td>
					fullname
				</td>
				<td>
					Pwd
				</td>
			</tr>
			<tr>
				<input type="hidden" name="id" value="<?php echo $id ?>">

				<td>
					<input type="text" name="USr" value="<?php echo $ad['USr'] ?>">
				</td>

				<td>
					<input type="text" name="fullname" value="<?php echo $ad['fullname'] ?>">
				</td>

				<td>
					<input type="text" name="Pwd" value="<?php echo $ad['Pwd'] ?>">
				</td>
			</tr>

			<tr>
				<td colspan="5" align="center" >
					<input type="submit" name="edit" value="THÊM">
				</td>
			</tr>
			
		</table>
	</form>
</body>
</html>