<?php

			$USr = $_POST['USr'];
			$fullname = $_POST['fullname'];
			$Pwd =$_POST['Pwd'];

			$con = mysqli_connect("localhost","root","","demo_db");
			$sql = "INSERT INTO user(USr,fullname,Pwd) VALUES ('$USr','$fullname','$Pwd')";
			$qr = mysqli_query($con,$sql);

			if ($qr) {
				header("location:index.php");
			}


		?>