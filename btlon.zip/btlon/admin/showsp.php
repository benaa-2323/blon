<?php 
	session_start();
	
	
?>
<!DOCTYPE html>
<html>
<head>
	<title>Sản Phẩm Đang Bán</title>
	<meta lang="en">
	<link href="../style.css" type="text/css" rel="stylesheet"/>
	<style type="text/css">

		img{
			width: 350px;
			height: 100px;
		}

	</style>
</head>
<body>

	

	<div id="product-grid">
		
		<div class="txt-heading">

			<h1>
				Sản Phẩm Đang Bán
			</h1>
			<form>
				<table border="1" cellpadding="10" cellspacing="0">
			<?php

			$con = mysqli_connect("localhost","root","","demo_db");
			$sql = "SELECT * from product";
			$qr = mysqli_query($con,$sql);
			
			while($lc = mysqli_fetch_array($qr)){
				?>
				
				<tr>
					<td>
						Tên Sản phẩm
					</td>
					<td>
						<?php echo $lc['name']; ?>
					</td>
				</tr>

				<tr>
					<td>
						Giá Tiền
					</td>
					<td>
						<?php echo number_format($lc['price']);?>
					</td>
				</tr>

				<tr>
					<td colspan="2">
						<img src="../IMG/<?php echo $lc['image'] ?>">
					</td>
				</tr>
				
				<tr>
					<td colspan="2"><?php echo '<a href="suasp.php?id='.$lc['id'].'"> Edit </a>'; ?></a></td>
				</tr>

			<?php } ?>


		</table>
			</form>
		</div>
		</div>
	<div style="width: 100%; margin-top: 20px; float: left; text-align: center;">
		<a href="index1.php">Quay Lại</a>
	</div>
</body>
</html>