<?php session_start(); ?><!DOCTYPE html>
<html>
<head>
	<title>trangchu</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="font-fa-master/css/font-awesome.css">
	<style type="text/css">
		#top{
			background: #000;
			color: white;
			height: 80px;
			}
		.fa fa-clock-o{
				font-size:40px;
			}

		img{
			margin-top: 10px;
			float: left;
			margin-left: 50px;
			border-top-left-radius: 5%;
			border-bottom-right-radius: 5%;
			width:280px;
			height: 250px;
		}
		.product-items{
			border:0px solid black;
			width: 550px;
			height: 300px;
			float: left;
		}
		#item{
			float: left;
			margin-left: 20px;

		}
		a{
			float: left;
			margin-left: 20px;
		}
		#mt{
			
			float: left;
			margin-left: 20px;
		}
		input[type='submit']{
			width:120px;
			margin-left: 20px;
		}
		input[type='text']{
			float: left;
			width:200px;
			margin-left: 20px;
		}
	</style>
</head>
<body>

	<div>
		<div id="top">
			<div class="container">
				<div class="row">
					<div class="col-4">
						<h5 align="center"><i class="fa fa-clock-o fa-2x"></i>30 DAYS RETURN</h5><p align="center">moneyback guarantee</p>
					</div>
					<div class="col-4">
						<h5 align="center"><i class="fa fa-truck fa-2x"></i>FREE SHIPPING ON $30</h5><p align="center">On all over order $99</p>
					</div>
					<div class="col-4">
						<h5 align="center"><i class="fa fa-tag fa-2x"></i> SAFE SHOPPING</h5><p align="center">Save up 50% to now</p>
					</div>
				</div>
			</div>
		</div>

		<div class="container shadow p-3 mb-5 bg-white" id="menu">
			<div class="row">
				<div class="col">
					<nav class="nav">
						<li class="nav-item dropdown">
			        		<a class="nav-link dropdown-toggle text-muted" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">English
			        		</a>
			        		<div class="dropdown-menu" aria-labelledby="navbarDropdown">
			          			<a class="dropdown-item text-muted" href="#">Action</a>
			          			<a class="dropdown-item text-muted" href="#">Another action</a>
			          			<div class="dropdown-divider"></div>
			          			<a class="dropdown-item text-muted" href="#">Something else here</a>
			     			</div>
			    		</li>
			    		<li class="nav-item dropdown">
				        	<a class="nav-link dropdown-toggle text-muted" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">USD
				        	</a>
				        	<div class="dropdown-menu" aria-labelledby="navbarDropdown">
				          		<a class="dropdown-item text-muted" href="#">Action</a>
				          		<a class="dropdown-item text-muted" href="#">Another action</a>
				          		<div class="dropdown-divider"></div>
				          		<a class="dropdown-item text-muted" href="#">Something else here</a>
				     		</div>
			    		</li>
					</nav>
				</div>

				<div class="row">
					<ul class="nav justify-content-end row">
						<li class="col-3">
	    					<a class="text-muted" href="#"><i class="fa fa-heart"></i>Whislist</a>
	 					</li>
	 					<li class="col-3">
	    					<a class="text-muted" href="../admin/index.php"><i class="fa fa-user"></i><?php 
	    						if (isset($_SESSION['user'])) {
	    							if ($_SESSION['user'] =="admin") {
	    							echo "<a href='../admin/index.php'>".$_SESSION['user']."</a>";
	    						}
	    						else{
	    							echo '<a href="">'.$_SESSION['user'].'</a>';
	    						}
	    						}
	    						else{
	    							echo "plz login";
	    						}
	    						



	    					 ?></a>
	 					
	 					<li class="col-3">
	    					<a class="text-muted" href="../login.php"><i class="fa fa-lock"></i>Login</a>
	 					</li>
	 					</li>
	 					<li class="col-3">
	    					<a class="text-muted" href="../logout.php"><i class="fa fa-check-square-o"></i>Log out</a>
	 					</li>
					</ul>
				</div>

			</div>
			<div class="row">
				<div class="col-4"></div>
				<div align="center" class="col-4">
					<h1 align="center">PHONE SHOP</h1><p align="center">Shop all you want</p>
				</div>
				<div class="col-4">
					<form class="form-inline my-2 my-lg-0">
				      <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
				      <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
				    </form>
				</div>
			</div>
			<div class="row">
				<div class="col">
					<nav class="nav">
						<li class="nav-item dropdown">
			        		<a class="nav-link dropdown-toggle text-muted" href="trangchu.php">HOME
			        		</a>
			        		<div class="dropdown-menu" aria-labelledby="navbarDropdown">
			          			<a class="dropdown-item text-muted" href="#">Action</a>
			          			<a class="dropdown-item text-muted" href="#">Another action</a>
			          			<div class="dropdown-divider"></div>
			          			<a class="dropdown-item text-muted" href="#">Something else here</a>
			     			</div>
			    		</li>
			    		<li class="nav-item dropdown">
				        	<a class="nav-link dropdown-toggle text-muted" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">NEW ARRIVALS
				        	</a>
				        	<div class="dropdown-menu" aria-labelledby="navbarDropdown">
				          		<a class="dropdown-item text-muted" href="#">Action</a>
				          		<a class="dropdown-item text-muted" href="#">Another action</a>
				          		<div class="dropdown-divider"></div>
				          		<a class="dropdown-item text-muted" href="#">Something else here</a>
				     		</div>
			    		</li>
			    		<li class="nav-item active">
					        <a class="nav-link text-dark" href="#">PROMOTION</a>
					    </li>
					    <li class="nav-item dropdown">
				        	<a class="nav-link dropdown-toggle text-muted" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">SPECIAL
				        	</a>
				        	<div class="dropdown-menu" aria-labelledby="navbarDropdown">
				          		<a class="dropdown-item text-muted" href="#">Action</a>
				          		<a class="dropdown-item text-muted" href="#">Another action</a>
				          		<div class="dropdown-divider"></div>
				          		<a class="dropdown-item text-muted" href="#">Something else here</a>
				     		</div>
			    		</li>
			    		<li class="nav-item active">
					        <a class="nav-link text-dark" href="#">BLOG</a>
					    </li>
					    <li class="nav-item active">
					        <a class="nav-link text-dark" href="#">CONTACT US</a>
					    </li>
					    <li class="nav-item active">
					        <a class="nav-link text-dark" href="#">ABOUT US</a>
					    </li>
		    		</nav>
				</div>
			</div>



		</div>
	</div>
	<?php

		include'../connect.php';
		//include'./pagination.php';
		$item_per_page = !empty($_GET['per_page']) ? $_GET['per_page']:4;

		$current_page = !empty($_GET['page']) ? $_GET['page']:1;
		$offset = ($current_page - 1) * $item_per_page ;
		$products = mysqli_query($con,"SELECT * FROM product ORDER BY id ASC LIMIT ".$item_per_page." OFFSET ".$offset);
		$totalRecords = mysqli_query($con,"SELECT* FROM product");
		$totalRecords = $totalRecords->num_rows;
		$totalPages = ceil($totalRecords /$item_per_page);

	?>
	<div class="container">
		<h1 align="center" style="color: red;">Danh sách sản phẩm</h1>
		<?php
			while ($row = mysqli_fetch_array($products))
				{


		?>
		<div class="product-items">
			<div>
				
				<?php echo '<img src="'.$row['image'].'"></img>' ."<br>" ?></div>
			<div>
			<b id="item">Tên : 	<?php echo $row['name']; ?>
				
			</b>
			<br>
			<span id="item">Giá: </span>
			<p id="item" class="product-price"><?php
			echo (number_format($row['price'])); ?>
			</p><br>
			
			</div><br>
			<p>
				<input type="text" name="sl" placeholder="   Nhập Số Lượng" value="">
			</p>
			<div class="buy-button">
				<br>
			<input type="submit" name="buy" value="Add to cart">	
			</div>
		</div>
		<?php
			}
		?>
	</div>	
	<div style="margin-top: 10px;float: left; margin-left: 500px" >
		<?php
	include '../pagination.php';
	?>
	</div>
	&nbsp;
				<div class="container" >

					<div class="row">
						<div class="col-2"></div>
						<div class="col-2">
							<h4>FOLLOW US</h4>
						</div>
						<div class="col-6">
							<i class="fa  fa-facebook-official" style="font-size: 35px;" id="icon"></i>
							<i class="fa  fa-twitter-square" style="font-size: 35px;" id="icon"></i>
							<i class="fa  fa-google-plus-square" style="font-size: 35px;" id="icon"></i>
							<i class="fa  fa-xing-square" style="font-size: 35px;" id="icon"></i>
							<i class="fa  fa-camera" style="font-size: 35px;" id="icon"></i>
							<i class="fa  fa-youtube-play" style="font-size: 35px;" id="icon"></i>
						</div>
						<div class="col-2"></div>
					</div>
				</div>

				<div class="container" style="margin-top: 20px">
				<div class="row">
					<div class="col-3">
						<div class="row">
							<div class="col-2"></div>
							<div class="col-10">
								<div class="row">
									<h5>OUR SHOP</h5>
								</div>

								<div class="row" style="opacity: 0.6;">
									Product Support
								</div>

								<div class="row" style="opacity: 0.6;">
									PC Setup & Support
								</div>

								<div class="row" style="opacity: 0.6;">
									Services
								</div>

								<div class="row" style="opacity: 0.6;">
									Extended Service Plans
								</div>

								<div class="row" style="opacity: 0.6;">
									Community
								</div>
							</div>
						</div>
					</div>
					<div class="col-2">
						<div class="row">
							<div class="col-2"></div>
							<div class="col-10">
								<div class="row">
									<h5> ORDERS</h5>
								</div>

								<div class="row" style="opacity: 0.6;">
									My Account 
								</div>

								<div class="row" style="opacity: 0.6;">
									Order Tracking
								</div>

								<div class="row" style="opacity: 0.6;">
									Watch Lish
								</div>

								<div class="row" style="opacity: 0.6;">
									Customer Service
								</div>

								<div class="row" style="opacity: 0.6;">
									Returns / Exchanges
								</div>
							</div>
						</div>
					</div>
					<div class="col-3">
						<div class="row">
							<div class="col-2"></div>
							<div class="col-10">
								<div class="row">
									<h5>OUR SHOP</h5>
								</div>

								<div class="row" style="opacity: 0.6;">
									Product Support
								</div>

								<div class="row" style="opacity: 0.6;">
									PC Setup & Support
								</div>

								<div class="row" style="opacity: 0.6;">
									Services
								</div>

								<div class="row" style="opacity: 0.6;">
									Extended Service Plans
								</div>

								<div class="row" style="opacity: 0.6;">
									Community
								</div>
							</div>
						</div>
					</div>
					<div class="col-4">
						<div class="row">
							<div class="col-12">
								<div class="row">
									<h5>CONTACT US</h5>
								</div>
								<div class="row">
									<div class="col-2">
										 <i class="fa  fa-get-pocket" style="font-size: 30px;"></i>
									</div>
									<div class="col-10" style="opacity: 0.6;">
										Address: No 40 Baria Street 133/2 NewYork City, NY United States
									</div>
								</div>

								<div class="row">
									<div class="col-2">
										<i class="fa  fa-envelope-square" style="font-size: 30px;"></i>
									</div>
									<div class="col-10" style="opacity: 0.6;">
										Email: contact@market.com
									</div>
								</div>

								<div class="row">
									<div class="col-2">
										<i class="fa fa-phone-square" style="font-size: 30px;"></i>
									</div>
									<div class="col-10" style="margin-top: -20px;">
										<p style="opacity: 0.6;">Phone 1: 0123456789</p>
										<p style="margin-top: -15px; opacity: 0.6;">Phone 2: 0123456789</p>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>

			<div class="container" style="background-color: #f2f2f2;">
				<div class="row">
					<div class="col-6" style="font-size: 15px;">
						&copy;2016 Magento Themes Demo Store. All Rights Reserved. Designed by <i style="color: green;">Phương Lan</i>
					</div>
					<div class="col-6">
						<div class="row">
							<div class="col-5"></div>
							<div class="col-7">
								<div class="row">
									<i class="fa  fa-cc-visa" style="font-size: 30px; opacity: 0.6;"></i>

									<i class="fa  fa-cc-paypal" style="font-size: 30px; opacity: 0.6;"></i>

									<i class="fa  fa-cc-diners-club" style="font-size: 30px; opacity: 0.6;"></i>

									<i class="fa  fa-cc-discover" style="font-size: 30px; opacity: 0.6;"></i>

									<i class="fa  fa-cc-mastercard" style="font-size: 30px; opacity: 0.6;"></i>

									<i class="fa  fa-cc-amex" style="font-size: 30px; opacity: 0.6;"></i>
								</div>
							</div>
						</div>
					</div>
				</div>
				
			</div>

	<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
	<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
</body>
</body>
</html>