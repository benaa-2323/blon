<?php
	session_start();

?>
<!DOCTYPE html>
<html>
<head>
	<title>Đăng Ký Tài  Khoản</title>
	<meta charset="utf-8">
	<style type="text/css">
		.content{
			text-align: center;
			border-style: outset;
			border-radius: 10px;
			background-color: pink;
			width: 400px;
			height: 300px;
			margin-top: 100px;
			margin-bottom: 100px;
			margin-right: 150px;
			margin-left: 370px;
		}
		h1{
			color: #6a5acd;
			text-shadow: 2px 2px red;
		}
		
	</style>
</head>
<body>

	<div class="content">
		<form method="POST" action="">

			<h1> Đăng Ký Tài Khoản</h1>
			<div class="row">
				<input type="text" name="username" size="40" placeholder="Username" />
			</div><br>

			<div class="row">
				
				<input type="text" name="fullname" size="40" placeholder="Fullname" />
			</div><br>

			<div class="row">
				
				<input type="password" name="password1" size="40" placeholder="Password" />
			</div><br>

			<div class="row">
				
				<input type="password" name="password2" size="40" placeholder="confirm password" />
			</div><br>


			<div class="row">
				<td colspan="2" align="center">
				<input type="submit" name="submit" value="đăng ký" size="10" />
				</td>
			</div>

			<?php
				
				$username ="";
				$fullname ="";
				$password ="";
				$confirm = "";

				if (isset($_POST['submit'])) {
					$username = $_POST['username'];
					$fullname = $_POST['fullname'];
					$password = $_POST['password1'];
					$confirm = $_POST['password2'];
					if ($password!=$confirm){
						echo "password wrong";
					}
					else{
						$con = mysqli_connect("localhost","root","","demo_db");
						$sql = "INSERT INTO user(USr,fullname,Pwd) VALUES ('$username','$fullname','$password')";
						$qr = mysqli_query($con,$sql);
						echo "creat account sucessful";

						header('location:login.php');
					}
				}

			?>
		</form>
	</div>

</body>
</html>